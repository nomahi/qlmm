# qlmm 1.1-1 (2025-01-14)

- first version released on GitHub
