coeff <- function(gm, type="CR0", cl=0.95, digit=3){

	requireNamespace("clubSandwich")

	cc <- 1 - 0.5*(1 - cl)

	sgm <- summary(gm)
	cgm <- sgm$coefficients

	Vm <- vcovCR(gm, type=type)
	se <- sqrt(diag(Vm))
		
	est <- cgm[,1]
	cl1 <- cgm[,1] - qnorm(cc)*se
	cl2 <- cgm[,1] + qnorm(cc)*se
	P <- 2*pnorm(-abs(cgm[,1]/se))
	
	R <- data.frame(est,se,cl1,cl2,P)
	colnames(R) <- c("coef","SE","CL","CU","P-value")
	R <- round(R,digit)
	return(R)
	
}

